import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';

@WebSocketGateway()
export class AppGateway {
  @WebSocketServer() server: Server;
  private connectedClients = new Map<string, string>(); // Map to store connectionId and userId
  private messages: { userId: string; text: string }[] = []; // Array to store messages

  handleConnection(client: Socket) {
    console.log(`Client connected: ${client.id}`);
  }

  handleDisconnect(client: Socket) {
    const userId = this.connectedClients.get(client.id);
    if (userId) {
      this.server.emit('message', `${userId} has left`);
      this.connectedClients.delete(client.id);
    }
  }

  @SubscribeMessage('sendPublicMessage')
  handlePublicMessage(
    @MessageBody() message: { userId: string; text: string },
  ) {
    this.messages.push(message); // Save message in the array
    this.server.emit('message', `${message.userId}: ${message.text}`);
  }

  @SubscribeMessage('sendPrivateMessage')
  handlePrivateMessage(
    @MessageBody()
    message: {
      fromUserId: string;
      toUserId: string;
      text: string;
    },
  ) {
    const recipientSocketId = [...this.connectedClients.entries()].find(
      ([key, value]) => value === message.toUserId,
    )?.[0];
    if (recipientSocketId) {
      this.server
        .to(recipientSocketId)
        .emit('message', `Private from ${message.fromUserId}: ${message.text}`);
      this.messages.push({ userId: message.fromUserId, text: message.text }); // Save message in the array
    }
  }

  @SubscribeMessage('identify')
  identify(@MessageBody() userId: string, @ConnectedSocket() client: Socket) {
    this.connectedClients.set(client.id, userId);
    this.server.emit('message', `${userId} has joined`);
  }
}
