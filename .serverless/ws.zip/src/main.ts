// import { NestFactory } from '@nestjs/core';
// import serverlessExpress from '@vendia/serverless-express';
// import { Context, Callback, Handler } from 'aws-lambda';
// import { AppModule } from './app.module';

// let server: Handler;
// async function bootstrap() {
//   const app = await NestFactory.create(AppModule);

//   app.enableCors();
//   await app.init();

//   const expressApp = app.getHttpAdapter().getInstance();
//   return serverlessExpress({ app: expressApp });
// }
// export const handler: Handler = async (
//   event: any,
//   context: Context,
//   callback: Callback,
// ) => {
//   server = server ?? (await bootstrap());
//   return server(event, context, callback);
// };

import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { Context, Callback, Handler } from 'aws-lambda';

import { Server } from 'socket.io';
import { configure as serverlessExpress } from '@vendia/serverless-express';
let server: Server;
let connectedClients = new Map<string, string>();
let messages: { userId: string; text: string }[] = [];

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.enableCors({
    origin: '*', // Adjust as per your requirement
    methods: 'GET,POST,PUT,DELETE,OPTIONS',
    allowedHeaders: [
      'Content-Type',
      'Accept',
      'Authorization',
      'User-Agent',
      'sec-ch-ua',
      'sec-ch-ua-mobile',
      'sec-ch-ua-platform',
      'Sec-Fetch-Site',
      'Sec-Fetch-Mode',
      'Sec-Fetch-Dest',
      'userdomain',
      'currentUser',
      'fqdn',
      'host',
    ].join(','),
  });
  await app.init();

  const expressApp = app.getHttpAdapter().getInstance();
  return serverlessExpress({ app: expressApp });
}

export const handler: Handler = async (
  event: any,
  context: Context,
  callback: Callback,
) => {
  if (!server) {
    await bootstrap();
  }

  const { requestContext, body } = event;
  const connectionId = requestContext.connectionId;
  const routeKey = requestContext.routeKey;

  switch (routeKey) {
    case '$connect':
      // Handle WebSocket connection
      console.log(`Client connected: ${connectionId}`);
      break;
    case '$disconnect':
      // Handle WebSocket disconnection
      const userId = connectedClients.get(connectionId);
      if (userId) {
        server.emit('message', `${userId} has left`);
        connectedClients.delete(connectionId);
      }
      break;
    case 'sendPublicMessage':
      // Handle public message
      const publicMessage = JSON.parse(body);
      messages.push(publicMessage);
      server.emit('message', `${publicMessage.userId}: ${publicMessage.text}`);
      break;
    case 'sendPrivateMessage':
      // Handle private message
      const privateMessage = JSON.parse(body);
      const recipientSocketId = [...connectedClients.entries()].find(
        ([key, value]) => value === privateMessage.toUserId,
      )?.[0];
      if (recipientSocketId) {
        server
          .to(recipientSocketId)
          .emit(
            'message',
            `Private from ${privateMessage.fromUserId}: ${privateMessage.text}`,
          );
        messages.push({
          userId: privateMessage.fromUserId,
          text: privateMessage.text,
        });
      }
      break;
    case 'identify':
      // Handle user identification
      const identifiedUserId = JSON.parse(body).userId;
      connectedClients.set(connectionId, identifiedUserId);
      server.emit('message', `${identifiedUserId} has joined`);
      break;
  }

  return { statusCode: 200, body: 'success' };
};
